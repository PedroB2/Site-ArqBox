
$('body').scrollspy({target: ".navbar"})